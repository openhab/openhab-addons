package com.github.tavalin.s20.protocol;

public class InvalidMessageException extends Exception {

    public InvalidMessageException(String err) {
        super(err);
    }

    /**
     * 
     */
    private static final long serialVersionUID = 3961321884320423989L;

}
