package com.github.tavalin.s20;

/**
 * The Class OrviboDevice.
 */
public abstract class OrviboDevice {

}
