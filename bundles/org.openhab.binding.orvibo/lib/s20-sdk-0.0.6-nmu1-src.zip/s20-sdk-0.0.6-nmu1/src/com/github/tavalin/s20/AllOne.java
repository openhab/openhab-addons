package com.github.tavalin.s20;

public class AllOne extends OrviboDevice {

}
