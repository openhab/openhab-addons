/*
 * Copyright (c) 2010-2026 Contributors to the openHAB project
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0
 *
 * SPDX-License-Identifier: EPL-2.0
 */
package org.openhab.binding.transitapp.internal.net.dto;

import java.util.List;

import org.eclipse.jdt.annotation.NonNullByDefault;
import org.eclipse.jdt.annotation.Nullable;

import com.google.gson.annotations.SerializedName;

@NonNullByDefault
public class StopDeparturesResult {
    @SerializedName("route_departures")
    public @Nullable List<RouteDeparture> routeDepartures;

    public static class RouteDeparture {
        @SerializedName("route_short_name")
        public @Nullable String routeShortName;
        @SerializedName("route_long_name")
        public @Nullable String routeLongName;
        public @Nullable List<Itinerary> itineraries;
    }

    public static class Itinerary {
        @SerializedName("schedule_items")
        public @Nullable List<ScheduleItem> scheduleItems;
    }

    public static class ScheduleItem {
        @SerializedName("scheduled_departure_time")
        public @Nullable Long scheduledDepartureTime;
        @SerializedName("departure_time")
        public @Nullable Long departureTime;
        @SerializedName("scheduled_arrival_time")
        public @Nullable Long scheduledArrivalTime;
        @SerializedName("arrival_time")
        public @Nullable Long arrivalTime;
        @SerializedName("is_cancelled")
        public @Nullable Boolean isCancelled;
        @SerializedName("is_real_time")
        public @Nullable Boolean isRealTime;
        @SerializedName("rt_trip_id")
        public @Nullable String rtTripId;
        @SerializedName("trip_search_key")
        public @Nullable String tripSearchKey;
        @SerializedName("wheelchair_accessible")
        public @Nullable Integer wheelchairAccessible; // Integer, not Boolean!
    }
}
