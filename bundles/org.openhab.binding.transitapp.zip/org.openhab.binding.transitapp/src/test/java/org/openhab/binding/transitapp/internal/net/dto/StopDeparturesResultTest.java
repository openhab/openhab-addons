/*
 * Copyright (c) 2010-2026 Contributors to the openHAB project
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0
 *
 * SPDX-License-Identifier: EPL-2.0
 */
package org.openhab.binding.transitapp.internal.net.dto;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.google.gson.Gson;

/**
 * Unit tests for StopDeparturesResult DTO deserialization.
 * 
 * @author openHAB Contributors
 */
public class StopDeparturesResultTest {

    private Gson gson;

    @BeforeEach
    public void setUp() {
        gson = new Gson();
    }

    @Test
    public void testScheduleItemDeserialization() {
        String json = """
                {
                  "route_departures": [
                    {
                      "route_short_name": "247",
                      "route_long_name": "Bus 247",
                      "itineraries": [
                        {
                          "schedule_items": [
                            {
                              "scheduled_departure_time": 1609459200,
                              "departure_time": 1609459260,
                              "scheduled_arrival_time": 1609460400,
                              "arrival_time": 1609460400,
                              "is_cancelled": false,
                              "is_real_time": true,
                              "rt_trip_id": "trip123",
                              "trip_search_key": "KEY123",
                              "wheelchair_accessible": 1
                            }
                          ]
                        }
                      ]
                    }
                  ]
                }
                """;

        StopDeparturesResult result = gson.fromJson(json, StopDeparturesResult.class);

        assertNotNull(result);
        assertNotNull(result.routeDepartures);
        assertEquals(1, result.routeDepartures.size());

        StopDeparturesResult.RouteDeparture route = result.routeDepartures.get(0);
        assertEquals("247", route.routeShortName);
        assertEquals("Bus 247", route.routeLongName);

        StopDeparturesResult.ScheduleItem schedule = route.itineraries.get(0).scheduleItems.get(0);
        assertEquals(1609459200L, schedule.scheduledDepartureTime);
        assertEquals(1609459260L, schedule.departureTime);
        assertEquals(1609460400L, schedule.scheduledArrivalTime);
        assertEquals(1609460400L, schedule.arrivalTime);
        assertEquals(false, schedule.isCancelled);
        assertEquals(true, schedule.isRealTime);
        assertEquals("trip123", schedule.rtTripId);
        assertEquals("KEY123", schedule.tripSearchKey);
        assertEquals(1, schedule.wheelchairAccessible); // Integer, not Boolean!
    }

    @Test
    public void testWheelchairAccessibleAsInteger() {
        // Verify that wheelchair_accessible is correctly parsed as Integer (0, 1, 2)
        String json = """
                {
                  "route_departures": [
                    {
                      "route_short_name": "U6",
                      "itineraries": [
                        {
                          "schedule_items": [
                            {
                              "scheduled_departure_time": 1000,
                              "departure_time": 1000,
                              "wheelchair_accessible": 2
                            }
                          ]
                        }
                      ]
                    }
                  ]
                }
                """;

        StopDeparturesResult result = gson.fromJson(json, StopDeparturesResult.class);
        StopDeparturesResult.ScheduleItem schedule = result.routeDepartures.get(0).itineraries.get(0).scheduleItems
                .get(0);

        assertNotNull(schedule.wheelchairAccessible);
        assertEquals(2, schedule.wheelchairAccessible);
        assertFalse(schedule.wheelchairAccessible instanceof Boolean);
    }

    @Test
    public void testMultipleDeparturesPerRoute() {
        // Test flattening scenario: multiple itineraries per route
        String json = """
                {
                  "route_departures": [
                    {
                      "route_short_name": "247",
                      "itineraries": [
                        {
                          "schedule_items": [
                            {
                              "scheduled_departure_time": 1000,
                              "departure_time": 1100,
                              "trip_search_key": "trip1"
                            },
                            {
                              "scheduled_departure_time": 2000,
                              "departure_time": 2100,
                              "trip_search_key": "trip2"
                            }
                          ]
                        }
                      ]
                    }
                  ]
                }
                """;

        StopDeparturesResult result = gson.fromJson(json, StopDeparturesResult.class);
        List<StopDeparturesResult.ScheduleItem> items = result.routeDepartures.get(0).itineraries.get(0).scheduleItems;

        assertEquals(2, items.size());
        assertEquals("trip1", items.get(0).tripSearchKey);
        assertEquals("trip2", items.get(1).tripSearchKey);
    }
}
