/*
 * Copyright (c) 2010-2026 Contributors to the openHAB project
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0
 *
 * SPDX-License-Identifier: EPL-2.0
 */
package org.openhab.binding.transitapp.internal.handler;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Unit tests for chronological departure ordering.
 * 
 * Verifies that departures from multiple routes are ordered chronologically,
 * not by API response grouping order.
 * 
 * @author openHAB Contributors
 */
public class DepartureOrderingTest {

    /**
     * Test scenario: Route 1 has departures at 1100s and 2100s.
     * Route 2 has departures at 1050s and 2050s.
     * 
     * Expected output: All sorted chronologically: 1050s, 1100s, 2050s, 2100s
     */
    @Test
    public void testChronologicalOrderingAcrossRoutes() {
        List<FlattenedDeparture> allDepartures = new ArrayList<>();

        // Route 1 departures (later in response)
        allDepartures.add(new FlattenedDeparture(1100, "247", "Bus 247"));
        allDepartures.add(new FlattenedDeparture(2100, "247", "Bus 247"));

        // Route 2 departures (earlier in response, but earlier times!)
        allDepartures.add(new FlattenedDeparture(1050, "U6", "U-Bahn 6"));
        allDepartures.add(new FlattenedDeparture(2050, "U6", "U-Bahn 6"));

        // Sort chronologically
        allDepartures.sort((a, b) -> Long.compare(a.departureTime, b.departureTime));

        // Verify order
        assertEquals(1050, allDepartures.get(0).departureTime);
        assertEquals("U6", allDepartures.get(0).routeShortName);

        assertEquals(1100, allDepartures.get(1).departureTime);
        assertEquals("247", allDepartures.get(1).routeShortName);

        assertEquals(2050, allDepartures.get(2).departureTime);
        assertEquals("U6", allDepartures.get(2).routeShortName);

        assertEquals(2100, allDepartures.get(3).departureTime);
        assertEquals("247", allDepartures.get(3).routeShortName);
    }

    /**
     * Test maxDepartures capping: only first N departures are published.
     */
    @Test
    public void testMaxDeparturesCapping() {
        List<FlattenedDeparture> allDepartures = new ArrayList<>();

        // Create 15 departures
        for (int i = 0; i < 15; i++) {
            allDepartures.add(new FlattenedDeparture(1000 + (i * 100), "BUS", "Bus Line"));
        }

        // Cap to 10
        int maxDepartures = 10;
        List<FlattenedDeparture> published = new ArrayList<>();
        for (FlattenedDeparture dep : allDepartures) {
            if (published.size() >= maxDepartures) {
                break;
            }
            published.add(dep);
        }

        assertEquals(10, published.size());
        assertEquals(1000, published.get(0).departureTime);
        assertEquals(1900, published.get(9).departureTime);
    }

    /**
     * Helper class simulating FlattenedDeparture from StopHandler.
     */
    public static class FlattenedDeparture {
        long departureTime;
        String routeShortName;
        String routeLongName;

        public FlattenedDeparture(long departureTime, String routeShortName, String routeLongName) {
            this.departureTime = departureTime;
            this.routeShortName = routeShortName;
            this.routeLongName = routeLongName;
        }
    }
}
